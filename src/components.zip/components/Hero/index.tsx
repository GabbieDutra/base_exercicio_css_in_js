import { HeroSection } from './styles'

const Hero = () => (
  <HeroSection>
    <h2>As melhores vagas para tecnologia</h2>
    <p>Encontre a vaga dos seus sonhos</p>
  </HeroSection>
)

export default Hero
